import { Routes } from '@angular/router';
import { LoginComponent } from './login/login';
import { RegisterComponent } from './register/register';
import { DonationsListComponent } from './donations-list/donations-list';
import { DonationsFormComponent } from './donations-form/donations-form';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'donations', component: DonationsListComponent },
  { path: 'donations/new', component: DonationsFormComponent },
  { path: 'donations/edit/:id', component: DonationsFormComponent },
];
