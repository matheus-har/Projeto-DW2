import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-donations-form',
  templateUrl: './donations-form.html',
  standalone: true,
  imports: [CommonModule, FormsModule]
})
export class DonationsFormComponent implements OnInit {
  donation: any = {
    donor: { id: null },
    recipient: { id: null },
    product_Id: { id: null },
    date: '',
    pickup_Location: '',
    active: true
  };
  users: any[] = [];
  products: any[] = [];
  isEdit = false;
  error = '';

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    this.loadUsers();
    this.loadProducts();

    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.http.get<any>('http://localhost:8080/donations/' + id)
        .subscribe({
          next: data => this.donation = data,
          error: err => this.error = 'Erro ao carregar doação'
        });
    }
  }

  loadUsers() {
    this.http.get<any[]>('http://localhost:8080/users')
      .subscribe({
        next: data => this.users = data,
        error: err => this.error = 'Erro ao carregar usuários'
      });
  }

  loadProducts() {
    this.http.get<any[]>('http://localhost:8080/products')
      .subscribe({
        next: data => this.products = data,
        error: err => this.error = 'Erro ao carregar produtos'
      });
  }

save() {
  
  if (this.donation.date && this.donation.date.includes('-')) {
    const [year, month, day] = this.donation.date.split('-');
    this.donation.date = `${day}/${month}/${year}`;
  }

  if (this.isEdit) {
    this.http.put('http://localhost:8080/donations/' + this.donation.id, this.donation)
      .subscribe({
        next: () => this.router.navigate(['/donations']),
        error: err => this.error = 'Erro ao salvar'
      });
  } else {
    this.http.post('http://localhost:8080/donations', this.donation)
      .subscribe({
        next: () => this.router.navigate(['/donations']),
        error: err => this.error = 'Erro ao cadastrar'
      });
  }
}
}