import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DonationsForm } from './donations-form';

describe('DonationsForm', () => {
  let component: DonationsForm;
  let fixture: ComponentFixture<DonationsForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DonationsForm]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DonationsForm);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
