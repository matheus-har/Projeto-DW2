import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.html',
  standalone: true,
  imports: [CommonModule, FormsModule]
})
export class RegisterComponent {
  name = '';
  email = '';
  password = '';
  birthDate = '';
  gender = '';
  telephone = '';
  active = true;
  error = '';

  constructor(private http: HttpClient, private router: Router) {}

  register() {
    // Converte a data do formato yyyy-MM-dd para dd/MM/yyyy
    let formattedDate = this.birthDate;
    if (formattedDate && formattedDate.includes('-')) {
      const [year, month, day] = formattedDate.split('-');
      formattedDate = `${day}/${month}/${year}`;
    }

    this.http.post('http://localhost:8080/users', {
      name: this.name,
      email: this.email,
      password: this.password,
      birthDate: formattedDate,
      gender: this.gender, // Deve ser "MASCULINO", "FEMININO", "OUTRO" ou "PREFIRO_NAO_DIZER"
      telephone: this.telephone,
      active: this.active
    }).subscribe({
      next: () => this.router.navigate(['/login']),
      error: err => this.error = 'Erro ao cadastrar: ' + (err.error?.message || err.statusText)
    });
  }
}
