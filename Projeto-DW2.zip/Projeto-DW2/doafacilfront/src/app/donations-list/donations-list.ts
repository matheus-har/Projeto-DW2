import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-donations-list',
  templateUrl: './donations-list.html',
   standalone: true,
  imports: [CommonModule, RouterModule]
})
export class DonationsListComponent {
  donations: any[] = [];
  error = '';

  constructor(
    private router: Router,
    private http: HttpClient
  ) {
    this.loadDonations();
  }

  loadDonations() {
    this.http.get<any[]>('http://localhost:8080/donations')
      .subscribe({
        next: data => this.donations = data,
        error: err => this.error = 'Erro ao carregar doações'
      });
  }

  editDonation(id: number) {
    this.router.navigate(['/donations/edit', id]);
  }

  deleteDonation(id: number) {
    if (confirm('Deseja excluir esta doação?')) {
      this.http.delete('http://localhost:8080/donations/' + id)
        .subscribe({
          next: () => this.loadDonations(),
          error: err => this.error = 'Erro ao excluir'
        });
    }
  }
}
