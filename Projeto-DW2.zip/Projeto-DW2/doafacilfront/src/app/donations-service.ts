import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class DonationsService {
  donations = [
    {
      id: 1,
      donor: { id: 1, name: 'Maria Costa' },
      recipient: { id: 2, name: 'João Silva' },
      product_Id: { id: 1, name: 'Boneca' },
      date: '06/04/2025',
      pickup_Location: 'Rua X',
      active: true
    }
  ];

  getDonations() {
    return this.donations;
  }

  addDonation(donation: any) {
    donation.id = this.donations.length ? Math.max(...this.donations.map(d => d.id)) + 1 : 1;
    this.donations.push({ ...donation });
  }

  updateDonation(id: number, updated: any) {
    const idx = this.donations.findIndex(d => d.id === id);
    if (idx !== -1) this.donations[idx] = { ...updated };
  }

  deleteDonation(id: number) {
    this.donations = this.donations.filter(d => d.id !== id);
  }

  getDonationById(id: number) {
    return this.donations.find(d => d.id === id);
  }
}
